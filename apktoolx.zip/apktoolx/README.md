A useful & powerful Bash script for "Reverse engineering Apk files"
First of all run install.sh for installing.

**Required** :
-: Apktool +2.3.1
-: Apksigner
-: lib32stdc++6
-: lib32ncurses6
-: lib32z1

Recommended run script with Super user access.
